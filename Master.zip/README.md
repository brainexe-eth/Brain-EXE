# MemeCoin Mint Website

An on-chain ERC-20 memecoin dApp built for Ethereum with transfer taxes and fair launch tokenomics.

---

## Features

- **Smart Contract**: ERC-20 with ETH-based minting, 65/35 supply split, transfer taxes (1% buy/sell → 0% after 200 tx), and owner controls.
- **Frontend**: Terminal-inspired minting interface powered by Ethers.js v6 and Tailwind CSS.
- **Tooling**: Hardhat for compilation, testing, and deployment.

---

## Project Structure

```
memecoin/
├── contracts/
│   └── BrainEXE.sol          # Solidity smart contract
├── scripts/
│   └── deploy.js             # Hardhat deployment script
├── frontend/
│   ├── index.html            # dApp UI
│   └── app.js                # dApp logic (Ethers.js)
├── hardhat.config.js         # Hardhat configuration
├── package.json
└── README.md
```

---

## Prerequisites

- [Node.js](https://nodejs.org/) v18+
- MetaMask browser extension
- RPC endpoint (optional, for testnet/mainnet)
- Etherscan API Key (optional, for verification)

---

## Installation

```bash
# 1. Install dependencies
npm install

# 2. Create environment file (optional, for testnet/mainnet deployment)
cp .env.example .env
# Edit .env and fill in PRIVATE_KEY, RPC URLs, and ETHERSCAN_API_KEY
```

---

## Compile Contract

```bash
npm run compile
```

---

## Deploy

### Local (Hardhat Network)

```bash
# Terminal 1: start local node
npx hardhat node

# Terminal 2: deploy
npm run deploy:local
```

### Sepolia Testnet

```bash
npm run deploy:sepolia
```

### Mainnet

```bash
npm run deploy:mainnet
```

> **Important**: Update `CONTRACT_ADDRESS` in `frontend/app.js` with the deployed contract address.

After deployment, call `setPair()` with the DEX pair address to activate transfer taxes.

---

## Verify on Etherscan

```bash
npx hardhat verify --network <network> <DEPLOYED_ADDRESS> <TREASURY_ADDRESS>
```

---

## Run Frontend

Open `frontend/index.html` in a modern browser (recommended with a live server):

```bash
# Using Python 3
python -m http.server 8080 --directory frontend

# Or use VS Code Live Server extension
```

Then open `http://localhost:8080` and connect MetaMask.

---

## Contract Parameters (Default)

| Parameter | Value |
|-----------|-------|
| Token Name | MemeCoin |
| Symbol | MEME |
| Decimals | 18 |
| Max Supply | 1,000,000,000 MEME |
| Public Mint | 650,000,000 MEME (65%) |
| Liquidity | 350,000,000 MEME (35%) |
| Mint Rate | 0.001 ETH = 50,000 MEME |
| Max Mint per Wallet | 500,000 MEME (0.01 ETH) |
| Buy Fee (Launch) | 1% |
| Sell Fee (Launch) | 1% |
| Fee Removal | After 200 taxable transactions |

The owner can update treasury, set DEX pair, toggle minting, and adjust wallet caps.

---

## Disclaimer

This project is for educational purposes only. Ensure a proper security audit is conducted before deploying to mainnet with real economic value.
