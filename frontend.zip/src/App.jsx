import { useState } from 'react';
import { createThirdwebClient, getContract, prepareContractCall } from 'thirdweb';
import { sepolia } from 'thirdweb/chains';
import { toEther, toWei } from 'thirdweb/utils';
import {
  useActiveAccount,
  useActiveWallet,
  useReadContract,
  useSendTransaction,
  useConnectModal,
  useDisconnect,
} from 'thirdweb/react';
import CoreInnovation from './components/CoreInnovation';
import Whitepaper from './components/Whitepaper';
import Manifesto from './components/Manifesto';

const CLIENT_ID = '5003f0d0502ba792138ac609d201ed27';
const CONTRACT_ADDRESS = '0xe7663C61A12d5c54530a17Fa295d3345DEF639a0';
const MINTABLE_SUPPLY = 650_000_000;
const RATE_ETH = 0.001;
const RATE_TOKENS = 50_000;

const client = createThirdwebClient({ clientId: CLIENT_ID });

const contract = getContract({
  client,
  chain: sepolia,
  address: CONTRACT_ADDRESS,
});

function fmtNumber(num) {
  if (num === undefined || num === null || Number.isNaN(num)) return '—';
  return Number(num).toLocaleString('en-US', { maximumFractionDigits: 0 });
}

function App() {
  const account = useActiveAccount();
  const address = account?.address;
  const activeWallet = useActiveWallet();
  const { connect, isConnecting } = useConnectModal();
  const { disconnect } = useDisconnect();

  const [ethInput, setEthInput] = useState('');
  const [message, setMessage] = useState('');
  const [txHash, setTxHash] = useState(null);
  const [activeTab, setActiveTab] = useState('mint');

  // (PQ inputs removed for simple mint flow)

  const { data: mintEnabled } = useReadContract({
    contract,
    method: 'function mintEnabled() view returns (bool)',
  });

  const { data: totalMinted } = useReadContract({
    contract,
    method: 'function totalMinted() view returns (uint256)',
  });

  const { data: maxMintPerWallet } = useReadContract({
    contract,
    method: 'function maxMintPerWallet() view returns (uint256)',
  });

  const { data: mintedByWallet } = useReadContract({
    contract,
    method: 'function mintedByWallet(address) view returns (uint256)',
    params: address ? [address] : undefined,
    queryOptions: { enabled: !!address },
  });

  const { data: burnFee } = useReadContract({
    contract,
    method: 'function burnFee() view returns (uint256)',
  });


  const { mutate: sendTransaction, isPending } = useSendTransaction();

  const mintedNum = totalMinted ? Number(toEther(totalMinted)) : 0;
  const percent = ((mintedNum / MINTABLE_SUPPLY) * 100).toFixed(2);
  const remaining = MINTABLE_SUPPLY - mintedNum;
  const maxWalletNum = maxMintPerWallet ? Number(toEther(maxMintPerWallet)) : 500_000;
  const mintedWalletNum = mintedByWallet && address ? Number(toEther(mintedByWallet)) : 0;
  const walletLeftTokens = maxWalletNum - mintedWalletNum;

  const tokenPreview = (() => {
    const val = parseFloat(ethInput);
    if (isNaN(val) || val <= 0) return '0';
    return fmtNumber((val / RATE_ETH) * RATE_TOKENS);
  })();

  const handleConnect = async () => {
    try {
      await connect({ client, chain: sepolia });
    } catch (err) {
      setMessage('Failed to connect wallet: ' + (err?.message || 'Unknown error'));
    }
  };

  const handleMax = () => {
    if (walletLeftTokens <= 0) { setEthInput('0'); return; }
    const ethLeft = (walletLeftTokens / RATE_TOKENS) * RATE_ETH;
    const rounded = Math.floor(ethLeft * 1000) / 1000;
    setEthInput(rounded > 0 ? rounded.toFixed(3) : '0');
  };

  const handleMint = async () => {
    const val = parseFloat(ethInput);
    if (isNaN(val) || val <= 0) { setMessage('Enter a valid ETH amount.'); return; }
    const tokensToMint = (val / RATE_ETH) * RATE_TOKENS;
    if (tokensToMint > walletLeftTokens) { setMessage('Exceeds wallet cap.'); return; }
    if (mintedNum + tokensToMint > MINTABLE_SUPPLY) { setMessage('Exceeds remaining public supply.'); return; }

    setMessage('Preparing transaction...');
    setTxHash(null);
    try {
      const wei = toWei(val.toString());
      const tx = prepareContractCall({ contract, method: 'function mint() payable', value: wei });
      await sendTransaction(tx, {
        onSuccess: (receipt) => { setMessage('Successfully minted!'); setTxHash(receipt.transactionHash); setEthInput(''); },
        onError: (err) => { setMessage('Transaction failed: ' + (err.message || 'User rejected')); },
      });
    } catch (err) {
      setMessage('Transaction failed: ' + (err.message || 'User rejected'));
    }
  };

  return (
    <div className="min-h-screen bg-paw-pattern relative overflow-x-hidden">
      {/* Floating background blobs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute -top-20 -left-20 w-96 h-96 rounded-full bg-orange-200 animate-blob opacity-40 blur-3xl" />
        <div className="absolute top-1/3 -right-20 w-80 h-80 rounded-full bg-pink-200 animate-blob opacity-40 blur-3xl" style={{ animationDelay: '2s' }} />
        <div className="absolute -bottom-20 left-1/4 w-96 h-96 rounded-full bg-yellow-100 animate-blob opacity-40 blur-3xl" style={{ animationDelay: '4s' }} />
      </div>

      {/* Navigation */}
      <nav className="sticky top-0 z-50 backdrop-blur-xl bg-white/60 border-b border-orange-100/50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-3 sm:py-4 flex items-center justify-between">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="w-9 h-9 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl clay-card-peach flex items-center justify-center text-xl sm:text-2xl">
              🐾
            </div>
            <span className="text-lg sm:text-2xl font-bold text-orange-800" style={{ fontFamily: 'Fredoka, sans-serif' }}>
              Brain EXE
            </span>
          </div>
          <div className="flex items-center gap-1 sm:gap-2">
            {[
              { id: 'mint', label: 'Mint', short: 'Mint' },
              { id: 'core', label: 'Core Innovation', short: 'Core' },
              { id: 'manifesto', label: 'Manifesto', short: 'Story' },
              { id: 'whitepaper', label: 'Whitepaper', short: 'Docs' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => { setActiveTab(tab.id); setMessage(''); }}
                className={`px-3 sm:px-5 py-2 sm:py-2.5 rounded-xl sm:rounded-2xl text-xs sm:text-sm font-bold transition-all whitespace-nowrap ${
                  activeTab === tab.id ? 'clay-button text-white' : 'text-orange-700 hover:bg-orange-100/50'
                }`}
              >
                <span className="sm:hidden">{tab.short}</span>
                <span className="hidden sm:inline">{tab.label}</span>
              </button>
            ))}
            {!address ? (
              <button onClick={handleConnect} disabled={isConnecting} className="clay-button px-3 sm:px-5 py-2 sm:py-2.5 text-xs sm:text-sm ml-1 sm:ml-2 whitespace-nowrap">
                {isConnecting ? '...' : 'Connect'}
              </button>
            ) : (
              <div className="flex items-center gap-1 sm:gap-2 ml-1 sm:ml-2">
                <div className="clay-card px-2 sm:px-3 py-1.5 sm:py-2 text-[10px] font-bold text-orange-800 font-mono hidden sm:block">
                  {address.slice(0, 6)}...{address.slice(-4)}
                </div>
                <button onClick={() => activeWallet && disconnect(activeWallet)} className="clay-button clay-button-secondary px-2 sm:px-3 py-2 sm:py-2.5 text-[10px] sm:text-xs">
                  ✕
                </button>
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* Mint Tab */}
      {activeTab === 'mint' && (
        <div className="relative z-10">
          <section className="pt-8 sm:pt-16 pb-8 sm:pb-12 px-4 sm:px-6">
            <div className="max-w-3xl mx-auto text-center">
              <div className="inline-flex items-center gap-2 px-4 sm:px-5 py-2 sm:py-2.5 rounded-full clay-card-yellow text-orange-800 text-xs sm:text-sm font-bold mb-6 sm:mb-8 animate-float-medium">
                🧠 $EXE Protocol
              </div>
              <h1 className="text-3xl sm:text-5xl md:text-6xl font-black text-orange-900 mb-4 sm:mb-6 leading-tight">
                Mint <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 via-pink-400 to-purple-400">$EXE</span>
              </h1>
              <p className="text-base sm:text-lg text-orange-800/70 max-w-xl mx-auto mb-6 sm:mb-8 leading-relaxed px-2">
                A sentient digital organism compiled on Ethereum. Post-quantum ready. Deflationary by design.
              </p>

              {/* Contract Address */}
              <div className="clay-card p-3 sm:p-4 max-w-lg mx-auto mb-8 sm:mb-10">
                <div className="text-[10px] sm:text-xs font-bold text-orange-800/50 uppercase tracking-wider mb-1">Contract Address</div>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-3">
                  <code className="text-xs sm:text-sm font-mono text-orange-900 font-bold break-all text-center">{CONTRACT_ADDRESS}</code>
                  <button onClick={() => navigator.clipboard.writeText(CONTRACT_ADDRESS)} className="shrink-0 clay-button px-3 py-1.5 text-xs w-full sm:w-auto">Copy</button>
                </div>
              </div>
            </div>
          </section>

          <section className="pb-12 sm:pb-20 px-4 sm:px-6">
            <div className="max-w-3xl mx-auto space-y-6 sm:space-y-8">
              {/* Real-time Allocation */}
              <div className="clay-card p-4 sm:p-6">
                <div className="text-[10px] text-orange-800/50 uppercase tracking-wider font-bold mb-3 text-center">Live Allocation</div>
                <div className="flex h-4 sm:h-5 rounded-full overflow-hidden mb-3">
                  <div className="h-full bg-orange-400 transition-all duration-700" style={{ width: `${((mintedNum / 1_000_000_000) * 100).toFixed(2)}%` }} />
                  <div className="h-full bg-teal-300 transition-all duration-700" style={{ width: `${((95 - (mintedNum / 1_000_000_000) * 100)).toFixed(2)}%` }} />
                  <div className="h-full bg-purple-300 transition-all duration-700" style={{ width: `5%` }} />
                </div>
                <div className="flex flex-wrap justify-center gap-x-4 gap-y-1 text-[10px] sm:text-xs font-bold">
                  <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-orange-400" /> Public {((mintedNum / 1_000_000_000) * 100).toFixed(2)}%</span>
                  <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-teal-300" /> LP {((95 - (mintedNum / 1_000_000_000) * 100)).toFixed(2)}%</span>
                  <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-purple-300" /> Team 5% 🔥</span>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
                {[
                  { label: 'Public Supply', value: '650,000,000', color: 'text-orange-600' },
                  { label: 'Rate', value: '0.001 ETH = 50K', color: 'text-pink-500' },
                  { label: 'Burn Fee', value: `${burnFee ? Number(burnFee) / 100 : 1}%`, color: 'text-red-500' },
                ].map((s, i) => (
                  <div key={i} className="clay-card p-3 sm:p-4 text-center">
                    <div className="text-[10px] text-orange-800/50 uppercase tracking-wider font-bold mb-1">{s.label}</div>
                    <div className={`font-black text-xs sm:text-sm ${s.color}`}>{s.value}</div>
                  </div>
                ))}
              </div>

              {/* Progress */}
              <div className="clay-card p-4 sm:p-6">
                <div className="flex justify-between items-end mb-3">
                  <span className="text-2xl font-black text-orange-900">{percent}%</span>
                  <span className="text-xs text-orange-800/50 font-bold">{remaining.toLocaleString()} remaining</span>
                </div>
                <div className="h-3 bg-orange-100 rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${Math.min(Number(percent), 100)}%`, background: 'linear-gradient(90deg, #FF9F7A 0%, #FF8A65 50%, #FFAB91 100%)' }} />
                </div>
                <div className="mt-3 flex justify-between text-[10px] text-orange-800/40 font-bold uppercase tracking-wider">
                  <span>{fmtNumber(mintedNum)} / 650,000,000 minted</span>
                  <span>cap: 650M $EXE (65%)</span>
                </div>
              </div>

              {/* Alerts */}
              {message && (
                <div className={`clay-card p-4 text-center text-sm font-bold ${message.toLowerCase().includes('failed') ? 'clay-card-peach text-orange-900' : message.toLowerCase().includes('success') ? 'clay-card-mint text-teal-900' : 'text-orange-800/50'}`}>
                  {message}
                </div>
              )}
              {txHash && (
                <div className="text-center">
                  <a href={`https://sepolia.etherscan.io/tx/${txHash}`} target="_blank" rel="noreferrer" className="text-[10px] text-orange-500 hover:text-orange-700 font-bold tracking-wider underline">view transaction on etherscan ↗</a>
                </div>
              )}

              {/* Mint Panel */}
              <div className="clay-card p-4 sm:p-6 md:p-8">
                <div className="flex items-center justify-between mb-4 sm:mb-6">
                  <h3 className="text-base sm:text-lg font-black text-orange-900">Mint Tokens</h3>
                  <span className={`px-2 sm:px-3 py-1 rounded-full text-[10px] font-black tracking-wider ${mintEnabled ? 'clay-card-mint text-teal-800' : 'clay-card-peach text-orange-800'}`}>
                    {mintEnabled ? 'ACTIVE' : 'PAUSED'}
                  </span>
                </div>
                <div className="grid sm:grid-cols-2 gap-4 sm:gap-6 mb-4 sm:mb-6">
                  <div>
                    <label className="block text-[10px] text-orange-800/50 uppercase tracking-wider font-bold mb-2">Send ETH</label>
                    <div className="flex gap-2">
                      <input type="number" placeholder="0.000" step="0.001" min="0.001" value={ethInput} onChange={(e) => setEthInput(e.target.value)} className="flex-1 clay-input px-3 sm:px-4 py-2.5 sm:py-3 text-orange-900 text-sm font-mono font-bold placeholder-orange-900/20" />
                      <button onClick={handleMax} className="clay-button clay-button-secondary px-3 sm:px-4 py-2.5 sm:py-3 text-xs">MAX</button>
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] text-orange-800/50 uppercase tracking-wider font-bold mb-2">Receive EXE</label>
                    <div className="clay-input px-3 sm:px-4 py-2.5 sm:py-3 text-sm text-orange-900 font-mono font-bold flex items-center">
                      <span>{tokenPreview}</span><span className="text-orange-800/30 ml-2">EXE</span>
                    </div>
                  </div>
                </div>
                {address && (
                  <div className="mb-4 text-[10px] text-orange-800/40 font-mono font-bold flex flex-wrap gap-x-4 gap-y-1">
                    <span>allowance: <span className="text-orange-900">{fmtNumber(mintedWalletNum)}</span> / <span className="text-orange-900">{fmtNumber(maxWalletNum)}</span> EXE</span>
                  </div>
                )}

                <button onClick={handleMint} disabled={isPending || !address || !mintEnabled} className="w-full clay-button py-3 sm:py-4 text-sm disabled:opacity-30 disabled:cursor-not-allowed">
                  {isPending ? 'Minting...' : !address ? 'Connect Wallet' : !mintEnabled ? 'Minting Paused' : 'Mint $EXE'}
                </button>
              </div>
            </div>
          </section>
        </div>
      )}

      {/* Core Innovation Tab */}
      {activeTab === 'core' && (
        <div className="relative z-10">
          <CoreInnovation />
        </div>
      )}

      {/* Manifesto Tab */}
      {activeTab === 'manifesto' && (
        <div className="relative z-10">
          <Manifesto />
        </div>
      )}

      {/* Whitepaper Tab */}
      {activeTab === 'whitepaper' && (
        <div className="relative z-10">
          <Whitepaper />
        </div>
      )}

      {/* Footer */}
      <footer className="relative z-10 py-10 sm:py-12 px-4 sm:px-6 border-t border-orange-100/50">
        <div className="max-w-3xl mx-auto text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl clay-card-peach flex items-center justify-center text-xl">🐾</div>
            <span className="text-xl font-black text-orange-900" style={{ fontFamily: 'Fredoka, sans-serif' }}>Brain EXE</span>
          </div>

          {/* Social Links */}
          <div className="flex items-center justify-center gap-3 mb-5">
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noreferrer"
              className="clay-button px-4 py-2.5 text-xs flex items-center gap-2"
            >
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
              Twitter
            </a>
            <a
              href="https://github.com"
              target="_blank"
              rel="noreferrer"
              className="clay-button clay-button-secondary px-4 py-2.5 text-xs flex items-center gap-2"
            >
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z"/></svg>
              GitHub
            </a>
          </div>

          <p className="text-xs text-orange-800/40 font-bold">this project is for educational purposes. always DYOR before transacting.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
